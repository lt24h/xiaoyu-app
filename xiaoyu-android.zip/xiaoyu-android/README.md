# 小鱼 · 独立应用（Android）

一个 WebView 外壳，点开就是她的手机版控制台，全屏、没有地址栏。

## 改地址

`app/src/main/res/values/strings.xml` 里：

```xml
<string name="app_url">http://192.168.0.108:3500/m</string>
```

## 编译

### 方式一：Android Studio（最省事）

1. Android Studio → Open → 选这个文件夹
2. 等 Gradle 同步完
3. 菜单 Build → Build Bundle(s)/APK(s) → Build APK(s)
4. 产物在 `app/build/outputs/apk/debug/app-debug.apk`

### 方式二：命令行

```bash
./gradlew assembleDebug
```

需要 JDK 17 + Android SDK（`ANDROID_HOME` 指向 SDK 目录）。

### 方式三：GitHub Actions

把整个文件夹推到 GitHub 仓库，加一个 workflow：

```yaml
name: build
on: [push, workflow_dispatch]
jobs:
  apk:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with: { distribution: temurin, java-version: '17' }
      - run: chmod +x gradlew && ./gradlew assembleDebug
      - uses: actions/upload-artifact@v4
        with: { name: xiaoyu-apk, path: app/build/outputs/apk/debug/*.apk }
```

跑完在 Actions 页面下载 artifact，就是可安装的 APK。

## 装到平板上

- 数据线拷过去点开装
- 或者放到内网服务器上下载

## 说明

- 用的是 `http://` 局域网地址，所以 `usesCleartextTraffic` 和 network_security_config 都开了
- 长按返回键退出
- 屏幕常亮（FLAG_KEEP_SCREEN_ON）
